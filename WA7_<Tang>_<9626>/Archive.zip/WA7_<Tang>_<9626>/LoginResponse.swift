//
//  LoginResponse.swift
//  WA6_<Tang>_<9626>
//
//  Created by evan tang on 10/29/24.
//

import Foundation

struct LoginResponse: Codable {
    let auth: Bool
    let token: String
}
