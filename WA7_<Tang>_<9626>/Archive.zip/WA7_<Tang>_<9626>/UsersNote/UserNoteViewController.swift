//
//  UserNoteViewController.swift
//  WA7_<Tang>_<9626>
//
//  Created by evan tang on 10/31/24.
//

import UIKit
import Alamofire

class UserNoteViewController: UIViewController {
    
    var loginResponse: LoginResponse!
    let addUserNoteScreen = UserNoteView()
    var userNotes = [Note]()
    
    override func loadView() {
        view = addUserNoteScreen
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        getAllNotes()
        addUserNoteScreen.addButton.addTarget(self, action: #selector(addNoteOnTapped), for: .touchUpInside)
        
        addUserNoteScreen.tableViewNotes.dataSource = self
        addUserNoteScreen.tableViewNotes.delegate = self
        
    }
    
    func getAllNotes() {
        if let url = URL(string: APIConfigs.noteURL + "getall"){
            AF.request(url, method: .get).responseData(completionHandler: { response in
                //MARK: retrieving the status code...
                let status = response.response?.statusCode
                
                switch response.result{
                case .success(let data):
                    //MARK: there was no network error...
                    
                    //status code is Optional, so unwrapping it...
                    if let uwStatusCode = status{
                        switch uwStatusCode{
                            case 200...299:
                            //MARK: the request was valid 200-level...
                            self.userNotes.removeAll()
                            let decoder = JSONDecoder()
                            do { 
                                let receiveData = try decoder.decode(Notes.self, from: data)
                                
                                for item in receiveData.notes {
                                    self.userNotes.append(item)
                                    print("Added note: \(self.userNotes)")
                                }
                                print(self.userNotes)
                                self.addUserNoteScreen.tableViewNotes.reloadData()
                                
                            }catch{
                                print("Error")
                            }
                                break
                    
                            case 400...499:
                            //MARK: the request was not valid 400-level...
                                print(data)
                                break
                    
                            default:
                            //MARK: probably a 500-level error...
                                print(data)
                                break
                    
                        }
                    }
                    break
                    
                case .failure(let error):
                    //MARK: there was a network error...
                    print(error)
                    break
                }
            })
        }
    }
    
    @objc func addNoteOnTapped() {
        if let url = URL(string: APIConfigs.noteURL+"post"){
            
            let parameters = ["text": addUserNoteScreen.textAddNote.text]
            let headers: HTTPHeaders = [
                "x-access-token": loginResponse.token
            ]
            AF.request(url, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: headers)
                .responseString { response in
                    //print("Server Response: \(response)")
                    switch response.result {
                    case .success(let responseString):
                        self.getAllNotes()
                        //print("Response String: \(responseString)")
                    case .failure(let error):
                        print("Request failed with error: \(error)")
                    }
                }
        }
    }

}

extension UserNoteViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("Number of rows: \(userNotes.count)")
        return userNotes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableView.dequeueReusableCell(withIdentifier: "text", for: indexPath) as! NotesTableViewCell
          let noteText = String(userNotes[indexPath.row].text)
          cell.labelName.text = noteText
          print("Configuring cell for row \(indexPath.row) with text: \(userNotes[indexPath.row])")
          return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //getContactDetails(name: self.contactNames[indexPath.row])
    }
}
