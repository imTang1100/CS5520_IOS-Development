//
//  Notes.swift
//  WA7_<Tang>_<9626>
//
//  Created by evan tang on 10/29/24.
//

import Foundation

struct Note: Codable {
    let id: String
    let userId: String
    var text: String
    let __v: Int
    
    init(id: String? = nil, userId: String? = nil, text: String? = nil, __v: Int) {
        self.id = id ?? ""
        self.userId = userId ?? ""
        self.text = text ?? ""
        self.__v = __v
    }
}

struct Notes: Codable {
    let notes: [Note]
}
