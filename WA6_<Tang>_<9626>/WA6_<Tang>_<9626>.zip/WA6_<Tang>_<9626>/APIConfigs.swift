//
//  APIConfigs.swift
//  app10
//
//  Created by evan tang on 10/17/24.
//

import Foundation

class APIConfigs{
    //MARK: API base URL...
    static let baseURL = "http://apis.sakibnm.work:8888/contacts/text/"
}
