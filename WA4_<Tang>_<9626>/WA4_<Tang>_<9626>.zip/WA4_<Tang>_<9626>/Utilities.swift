//
//  Utilities.swift
//  WA4_<Tang>_<9626>
//
//  Created by evan tang on 10/2/24.
//

import Foundation

class Utilities{
    static let types = ["Cell", "Work", "Home"]
}
