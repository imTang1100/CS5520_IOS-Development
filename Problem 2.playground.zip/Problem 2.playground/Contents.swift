import UIKit

//MARK: Question 2, Sort and Array by String length

/* Create a function that takes an array of strings and return an array, sorted from shortest to longest.
 
 sortByLength(["Google", "Apple", "Microsoft"])
 ➞ ["Apple", "Google", "Microsoft"]

 sortByLength(["Leonardo", "Michelangelo", "Raphael", "Donatello"])
 ➞ ["Raphael", "Leonardo", "Donatello", "Michelangelo"]

 sortByLength(["Turing", "Einstein", "Jung"])
 ➞ ["Jung", "Turing", "Einstein"]
 
 Borrowed from: edabit.com
 */

func sortByLength (arr: [String]) -> [String] {
    // using closures inside a function
    return arr.sorted(by: { (string1, string2) -> Bool in
        return string1.count < string2.count})
}

//Calling the function
// let sortedArray = sortByLength(...)
// print(sortedArray)

let sortedArray1 = sortByLength(arr: ["Google", "Apple", "Microsoft"])
print(sortedArray1)  // Output: ["Apple", "Google", "Microsoft"]

let sortedArray2 = sortByLength(arr: ["Leonardo", "Michelangelo", "Raphael", "Donatello"])
print(sortedArray2)  // Output: ["Raphael", "Leonardo", "Donatello", "Michelangelo"]

let sortedArray3 = sortByLength(arr: ["Turing", "Einstein", "Jung"])
print(sortedArray3)  // Output: ["Jung", "Turing", "Einstein"]
